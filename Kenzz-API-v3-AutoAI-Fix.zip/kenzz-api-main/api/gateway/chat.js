import { createHash } from "node:crypto";
import { adminDb } from "../../_lib/supabase.js";
import { bearer, send, methodOnly, bodyObject } from "../../_lib/http.js";

const hashKey = key => createHash("sha256").update(key).digest("hex");
const PROVIDERS = {
  groq: { env: "GROQ_API_KEY", base: process.env.GROQ_BASE_URL || "https://api.groq.com/openai/v1", model: "llama-3.3-70b-versatile" },
  openai: { env: "OPENAI_API_KEY", base: process.env.OPENAI_BASE_URL || "https://api.openai.com/v1", model: "gpt-4o-mini" },
  deepseek: { env: "DEEPSEEK_API_KEY", base: process.env.DEEPSEEK_BASE_URL || "https://api.deepseek.com/v1", model: "deepseek-chat" },
  mistral: { env: "MISTRAL_API_KEY", base: process.env.MISTRAL_BASE_URL || "https://api.mistral.ai/v1", model: "mistral-small-latest" },
  together: { env: "TOGETHER_API_KEY", base: process.env.TOGETHER_BASE_URL || "https://api.together.xyz/v1", model: "meta-llama/Llama-3.3-70B-Instruct-Turbo" },
  gemini: { env: "GEMINI_API_KEY", model: "gemini-2.5-flash" }
};
const AUTO_ORDER = ["groq", "gemini", "deepseek", "openai", "mistral", "together"];

function geminiContents(messages) {
  const system = messages.filter(m => m.role === "system").map(m => m.content).join("\n");
  const contents = messages.filter(m => m.role !== "system").map(m => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: (m.role === "user" && system ? `System instructions:\n${system}\n\n` : "") + m.content }]
  }));
  return contents;
}
function normalizeGemini(data, model) {
  const text = (data.candidates?.[0]?.content?.parts || []).map(p => p.text || "").join("");
  const u = data.usageMetadata || {};
  return { id: `kenzz-${Date.now()}`, object: "chat.completion", created: Math.floor(Date.now()/1000), model,
    choices: [{ index: 0, message: { role: "assistant", content: text }, finish_reason: data.candidates?.[0]?.finishReason || "stop" }],
    usage: { prompt_tokens: u.promptTokenCount || 0, completion_tokens: u.candidatesTokenCount || 0, total_tokens: u.totalTokenCount || 0 } };
}
async function callProvider(name, messages, requestedModel, body) {
  const p = PROVIDERS[name], key = process.env[p.env];
  if (!key) throw Object.assign(new Error(`${name} not configured`), { unavailable: true });
  const model = requestedModel && requestedModel !== "kenzz-auto" ? requestedModel : p.model;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25000);
  try {
    let url, headers, payload;
    if (name === "gemini") {
      url = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
      headers = { "Content-Type": "application/json" };
      payload = { contents: geminiContents(messages), generationConfig: { temperature: Number.isFinite(body.temperature) ? Math.max(0,Math.min(2,body.temperature)) : 0.7, maxOutputTokens: Number.isInteger(body.max_tokens) ? Math.max(1,Math.min(4096,body.max_tokens)) : 1024 } };
    } else {
      url = `${p.base.replace(/\/$/, "")}/chat/completions`;
      headers = { Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
      payload = { model, messages, temperature: Number.isFinite(body.temperature) ? Math.max(0,Math.min(2,body.temperature)) : 0.7, max_tokens: Number.isInteger(body.max_tokens) ? Math.max(1,Math.min(4096,body.max_tokens)) : 1024 };
    }
    const response = await fetch(url, { method: "POST", headers, body: JSON.stringify(payload), signal: controller.signal });
    const raw = await response.text();
    let data; try { data = JSON.parse(raw); } catch { data = { error: { message: "Provider returned invalid JSON" } }; }
    if (!response.ok) throw Object.assign(new Error(data?.error?.message || `Provider HTTP ${response.status}`), { status: response.status, providerData: data });
    return { result: name === "gemini" ? normalizeGemini(data, model) : data, model, status: response.status };
  } finally { clearTimeout(timer); }
}

export default async function handler(req, res) {
  if (!methodOnly(req, res, "POST")) return;
  const raw = bearer(req);
  if (!raw.startsWith("kenzz_live_")) return send(res, 401, { error: "Valid Kenzz API key required" });
  const { data: key, error: keyErr } = await adminDb.from("api_keys").select("id,user_id,status,requests_count").eq("key_hash", hashKey(raw)).maybeSingle();
  if (keyErr || !key || key.status !== "active") return send(res, 401, { error: "Invalid or revoked API key" });
  const { data: profile } = await adminDb.from("profiles").select("status").eq("id", key.user_id).maybeSingle();
  if (!profile || profile.status === "blocked") return send(res, 403, { error: "Account blocked or profile unavailable" });
  const body = bodyObject(req);
  const messages = body.messages;
  if (!Array.isArray(messages) || !messages.length || messages.length > 40 || messages.some(m => !m || !["system","user","assistant"].includes(m.role) || typeof m.content !== "string"))
    return send(res, 400, { error: "messages must contain 1 to 40 valid messages" });
  const requested = String(body.provider || "auto").toLowerCase();
  const candidates = requested === "auto" || requested === "kenzz-auto" ? AUTO_ORDER : [requested];
  if (candidates.some(n => !PROVIDERS[n])) return send(res, 400, { error: "Unsupported provider", supported: [...Object.keys(PROVIDERS), "auto", "kenzz-auto"] });
  const available = candidates.filter(n => process.env[PROVIDERS[n].env]);
  if (!available.length) return send(res, 503, { error: "No configured provider available", providers: candidates });
  const { data: gate, error: gateError } = await adminDb.rpc("kenzz_consume_request", { p_user_id: key.user_id });
  if (gateError) return send(res, 503, { error: "Rate limit service unavailable. Check schema.sql RPC." });
  if (!gate?.allowed) { res.setHeader("Retry-After", String(gate.retry_after || 60)); return send(res, 429, { error: gate.reason || "Request limit exceeded", retry_after: gate.retry_after || 60 }); }

  const started = Date.now(); let lastError = null;
  for (const name of available) {
    try {
      const { result, model, status } = await callProvider(name, messages, body.model, body);
      const usage = result.usage || {};
      await adminDb.from("api_usage").insert({ api_key_id:key.id,user_id:key.user_id,provider:name,model,status_code:status,prompt_tokens:usage.prompt_tokens||0,completion_tokens:usage.completion_tokens||0,latency_ms:Date.now()-started });
      await adminDb.from("api_keys").update({ requests_count:(key.requests_count||0)+1,last_used_at:new Date().toISOString() }).eq("id",key.id);
      res.setHeader("X-Kenzz-Provider", name);
      return send(res, status, result);
    } catch (e) {
      lastError = e;
      await adminDb.from("api_usage").insert({ api_key_id:key.id,user_id:key.user_id,provider:name,model:body.model||PROVIDERS[name].model,status_code:e.status||502,latency_ms:Date.now()-started,error_message:String(e.message||"Provider error").slice(0,300) });
      // Explicit provider selection does not silently switch providers. Auto mode fails over on provider errors.
      if (requested !== "auto" && requested !== "kenzz-auto") break;
    }
  }
  return send(res, 502, { error: "All selected AI providers failed", detail: String(lastError?.message || "Provider unavailable").slice(0,240) });
}
